# NJ's Edu Avenue — Spoken English Master Class

Android Studio project for an offline-first 90-day Spoken English learning app, now populated from the supplied 24-session textbook.

## Included
- Home dashboard
- 90-day course overview
- Lesson list
- Daily English speaking practice
- Quiz
- Student progress (local UI)
- Full 24-session textbook content embedded in `app/src/main/assets/sessions.json`
- Teacher/contact/admission information
- NJ's Edu Avenue logo supplied by the user

## Course
Teacher: NAGENDRA T N
Phone/WhatsApp: 7483011182
Address: Above Vysya Co-operative Bank, Opp. TVV Petrol Bunk, GBN Road, Madhugiri 572132
Duration: 90 Days

## Build
Open this folder in Android Studio with JDK 17 and run the `app` configuration.
Then use Build > Build APK(s).

The app now uses the supplied NJ's Edu Avenue Advanced Basic Spoken English 24-Session Textbook as its core course content. The original textbook structure—vocabulary, formal vs natural/informal expressions, grammar/communication practice, everyday conversation, session review, speaking practice and home practice—is retained in the embedded session content.


## Latest app enhancements
- Standard methodology: LEARN → PRACTICE → TRANSLATE → SPEAK
- Branded splash screen using the NJ logo
- Dedicated launcher icon
- Lesson-by-lesson study interface for all 24 sessions
- Contact number displayed as +91 7483011182
