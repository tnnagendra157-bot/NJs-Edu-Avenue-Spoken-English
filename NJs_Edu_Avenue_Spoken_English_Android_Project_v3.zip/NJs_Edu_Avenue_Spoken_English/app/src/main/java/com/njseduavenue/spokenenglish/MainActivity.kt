package com.njseduavenue.spokenenglish

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

data class Session(val day: Int, val title: String, val content: String)

data class QuizQuestion(val question: String, val options: List<String>, val answer: Int)

private val Navy = Color(0xFF061A36)
private val Gold = Color(0xFFFFC107)
private val Light = Color(0xFFF5F7FA)

private val quiz = listOf(
    QuizQuestion("Choose the correct sentence.", listOf("He go to school.", "He goes to school.", "He going school."), 1),
    QuizQuestion("What is the opposite of 'early'?", listOf("Late", "Fast", "Small"), 0),
    QuizQuestion("Choose the correct greeting for the morning.", listOf("Good night", "Good morning", "Good evening"), 1),
    QuizQuestion("Complete: I ___ a student.", listOf("am", "is", "are"), 0),
    QuizQuestion("Choose the polite request.", listOf("Give me water.", "Water!", "Could you please give me some water?"), 2)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private fun loadSessions(context: android.content.Context): List<Session> {
    val raw = context.assets.open("sessions.json").bufferedReader().use { it.readText() }
    val arr = JSONArray(raw)
    return buildList {
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            add(Session(o.getInt("day"), o.getString("title"), o.getString("content")))
        }
    }
}

@Composable
fun App() {
    val context = LocalContext.current
    val sessions = remember { loadSessions(context) }
    var tab by remember { mutableIntStateOf(0) }
    var selectedSession by remember { mutableStateOf<Session?>(null) }
    var showSplash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(1500)
        showSplash = false
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Light, surface = Color.White, onPrimary = Color.White)) {
        if (showSplash) {
            SplashScreen()
            return@MaterialTheme
        }
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf("Home" to Icons.Default.Home, "Course" to Icons.Default.MenuBook, "Practice" to Icons.Default.RecordVoiceOver, "Quiz" to Icons.Default.Quiz, "Contact" to Icons.Default.Phone)
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(selected = tab == index, onClick = { tab = index; selectedSession = null }, icon = { Icon(item.second, null) }, label = { Text(item.first) })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                if (selectedSession != null) SessionDetailScreen(selectedSession!!) { selectedSession = null }
                else when (tab) {
                    0 -> HomeScreen(sessions, onLessons = { tab = 1 }, onPractice = { tab = 2 })
                    1 -> LessonsScreen(sessions) { selectedSession = it }
                    2 -> PracticeScreen()
                    3 -> QuizScreen()
                    else -> ContactScreen()
                }
            }
        }
    }
}

@Composable
fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painterResource(R.drawable.nj_app_icon),
                "NJ's Edu Avenue logo",
                Modifier.size(170.dp).clip(RoundedCornerShape(85.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(22.dp))
            Text("NJ's Edu Avenue", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Spoken English Master Class", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("Madhugiri", color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().background(Navy).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.nj_logo), "NJ's Edu Avenue logo", Modifier.size(58.dp).clip(RoundedCornerShape(29.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(14.dp))
        Column {
            Text("NJ's Edu Avenue", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Spoken English Master Class", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("Madhugiri", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
        }
    }
}

@Composable
fun HomeScreen(sessions: List<Session>, onLessons: () -> Unit, onPractice: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Light)) {
        Header()
        Column(Modifier.padding(18.dp)) {
            Text("Speak English with Confidence", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Navy)
            Spacer(Modifier.height(8.dp))
            Text("Advanced Basic Spoken English — a practical 24-session textbook focused on Grammar, Vocabulary, Natural Conversation and Speaking.")
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("90", "Days", Icons.Default.CalendarMonth, Modifier.weight(1f))
                StatCard("24", "Sessions", Icons.Default.MenuBook, Modifier.weight(1f))
                StatCard("2026", "Edition", Icons.Default.School, Modifier.weight(1f))
            }
            Spacer(Modifier.height(20.dp))
            SectionCard("Complete Course", "All 24 sessions from the NJ's Edu Avenue textbook are built into the app.") {
                Button(onClick = onLessons, Modifier.fillMaxWidth()) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("Open 24 Sessions") }
            }
            Spacer(Modifier.height(12.dp))
            SectionCard("Speaking Practice", "Practise aloud, pair up, and build natural speaking confidence.") {
                OutlinedButton(onClick = onPractice, Modifier.fillMaxWidth()) { Icon(Icons.Default.RecordVoiceOver, null); Spacer(Modifier.width(8.dp)); Text("Practice Now") }
            }
            Spacer(Modifier.height(12.dp))
            SectionCard("Textbook Method", "Each session follows the source textbook's speaking-first structure.") {
                Bullet("Vocabulary")
                Bullet("Formal vs Natural / Informal expressions")
                Bullet("Grammar in Context")
                Bullet("Everyday Conversation")
                Bullet("Session Review")
                Bullet("Speaking Practice & Home Practice")
            }
            Spacer(Modifier.height(12.dp))
            SectionCard("Standard Learning Methodology", "Follow the same four-step cycle in every lesson.") {
                MethodStep("1", "LEARN", "Understand the lesson, vocabulary and grammar." )
                MethodStep("2", "PRACTICE", "Use guided examples and conversations." )
                MethodStep("3", "TRANSLATE", "Translate practice sentences into natural English." )
                MethodStep("4", "SPEAK", "Speak aloud and give a short independent response." )
            }
            Spacer(Modifier.height(18.dp))
            Text("Teacher: NAGENDRA T N", fontWeight = FontWeight.Bold, color = Navy)
            Text("Course: Advanced Basic Spoken English", fontSize = 13.sp)
        }
    }
}

@Composable
fun StatCard(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Gold, Modifier.size(25.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text(label, fontSize = 11.sp)
        }
    }
}

@Composable
fun SectionCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
            if (subtitle.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(subtitle, fontSize = 13.sp) }
            Spacer(Modifier.height(12.dp)); content()
        }
    }
}

@Composable
fun Bullet(text: String) {
    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.CheckCircle, null, tint = Gold, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(text)
    }
}

@Composable
fun MethodStep(number: String, title: String, description: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(19.dp)).background(Navy), contentAlignment = Alignment.Center) {
            Text(number, color = Gold, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(description, fontSize = 12.sp)
        }
    }
}

@Composable
fun LessonsScreen(sessions: List<Session>, open: (Session) -> Unit) {
    Column(Modifier.fillMaxSize().background(Light)) {
        Header()
        Text("90-Day Course • 24 Sessions", Modifier.padding(18.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 0.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(sessions) { session ->
                Card(Modifier.fillMaxWidth().clickable { open(session) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Navy), contentAlignment = Alignment.Center) { Text("${session.day}", color = Gold, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(session.title, fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp)
                            Text("Tap to study full session", fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Navy)
                    }
                }
            }
        }
    }
}

@Composable
fun SessionDetailScreen(session: Session, back: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Light)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("Session ${session.day}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            Text(session.title, color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Text(session.content, fontSize = 14.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(18.dp))
            SectionCard("Study Method", "Learn → Practice → Translate → Speak") {
                MethodStep("1", "LEARN", "Study the lesson content and key language." )
                MethodStep("2", "PRACTICE", "Work through the grammar and conversation examples." )
                MethodStep("3", "TRANSLATE", "Translate selected practice sentences into English." )
                MethodStep("4", "SPEAK", "Speak without reading and build natural fluency." )
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
fun PracticeScreen() {
    val sentences = listOf("Good morning. How are you today?", "Could you please help me?", "I would like to improve my English.", "What did you do yesterday?", "What are you planning to do tomorrow?", "Could you repeat that, please?", "I understand what you mean.", "I am not sure. Let me think.")
    Column(Modifier.fillMaxSize().background(Light)) {
        Header()
        Column(Modifier.padding(18.dp)) {
            Text("Daily Speaking Practice", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text("Read each sentence aloud and repeat it 3 times.", Modifier.padding(top = 5.dp))
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(sentences) { s -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.VolumeUp, null, tint = Gold); Spacer(Modifier.width(12.dp)); Text(s, Modifier.weight(1f), fontSize = 16.sp) } } }
            }
        }
    }
}

@Composable
fun QuizScreen() {
    var current by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    val q = quiz[current]
    Column(Modifier.fillMaxSize().background(Light).verticalScroll(rememberScrollState())) {
        Header(); Column(Modifier.padding(18.dp)) {
            Text("Quick Quiz", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy); Text("Question ${current + 1} of ${quiz.size}")
            Spacer(Modifier.height(18.dp)); Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
                Text(q.question, fontSize = 19.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp))
                q.options.forEachIndexed { i, option -> Row(Modifier.fillMaxWidth().clickable { selected = i }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected == i, { selected = i }); Text(option) } }
                Spacer(Modifier.height(10.dp)); Button(onClick = { if (selected == q.answer) score++; selected = -1; current = (current + 1) % quiz.size }, enabled = selected >= 0, Modifier.fillMaxWidth()) { Text("Submit & Next") }
            } }
            Spacer(Modifier.height(16.dp)); Text("Practice score: $score", fontWeight = FontWeight.Bold, color = Navy)
        }
    }
}

@Composable
fun ContactScreen() {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().background(Light).verticalScroll(rememberScrollState())) {
        Header(); Column(Modifier.padding(18.dp)) {
            Text("Contact & Admission", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy); Spacer(Modifier.height(12.dp))
            SectionCard("NJ's Edu Avenue", "Spoken English Classes – Madhugiri") {
                Text("Teacher", fontWeight = FontWeight.Bold); Text("NAGENDRA T N"); Spacer(Modifier.height(10.dp))
                Text("Course Duration", fontWeight = FontWeight.Bold); Text("90 Days"); Spacer(Modifier.height(10.dp))
                Text("Address", fontWeight = FontWeight.Bold); Text("Above Vysya Co-operative Bank, Opp. TVV Petrol Bunk, GBN Road, Madhugiri 572132"); Spacer(Modifier.height(18.dp))
                Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/917483011182"))) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Message, null); Spacer(Modifier.width(8.dp)); Text("WhatsApp: +91 7483011182") }
                Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:7483011182"))) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Call, null); Spacer(Modifier.width(8.dp)); Text("Call +91 7483011182") }
            }
        }
    }
}
